package sma;

//import java.awt.Label;

import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.gui.GuiEvent;
import jade.util.ExtendedProperties;
import jade.util.leap.Properties;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.ControllerException;
import javafx.application.Application;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import sma.agents.EntrepotAgent;
import sma.agents.WagonAgent;

public class EntrepotContainer extends Application {
	private EntrepotAgent entrepotAgent;
	private ObservableList<String> observableList;
	

	
	public EntrepotAgent getEntrepotAgent() {
		return entrepotAgent;
	}

	public void setEntrepotAgent(EntrepotAgent entrepotAgent) {
		this.entrepotAgent = entrepotAgent;
	}

	// Méthode, Reception de courrier et confirme la reception de WagonAgent puis les affiches sous forme de liste
	public void vueMessage(GuiEvent guiEvent){
		String message=guiEvent.getParameter(0).toString();
		observableList.add(message);
		
	}

	public static void main(String[] args) {
		 // Lancer l'interface
		 launch(EntrepotContainer.class);
	}
	
	// Couper tout le code qui est dans main et on cré une méthode pour deposer
	private void lancerContainer() {
		// TODO Auto-generated method stub
		
		try {
			// Remarque Un contenaire est aussi une application
			// Creation d'un objet runtime fornie par jade (c'est une instance jade)
			Runtime runtime=Runtime.instance();
			// creation d'un objet profile pour un container et non pour un mainContainer
			Profile profile=new ProfileImpl(false);
			// Especifier ou se trouve le mainContainer, ce container vas se connecter vers le maincontenair
			 profile.setParameter(Profile.MAIN_HOST, "localhost");
			// Creation d'un agent container
			 AgentContainer agentContainer=runtime.createAgentContainer(profile);
			// Deployons un agent EntrepotAgent dans ce container
			 AgentController agentController=agentContainer.createNewAgent("entrepot1", "sma.agents.EntrepotAgent", new Object[]{this});
			 // On le demarre
			 // Au lieu de demarer le contenaire agentContainer.start();
			 // on demare directement agent, puis que quand il se demare, il demarre aussi le container
			 agentController.start();
		} catch (ControllerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	

	//Dès l'instanciation de la classe a partir de Application, cette Methode est génerée
	@Override
	public void start(Stage primaryStage) throws Exception {
		lancerContainer();
		primaryStage.setTitle("Entrepot");
		// une scene utilise le composant principal, ici c'est le container, c'est un objet de type borderPane
		// Border-pan c'est un paneau qui se divise en 05 zone (Nord, S,E,O, centre)
		BorderPane borderPane=new BorderPane();
		HBox hBox=new HBox(); 
		//espace sur les bordures
		hBox.setPadding(new Insets(10, 10, 10, 10));
		// espace entre les objets
		hBox.setSpacing(10);
		Label labelCourier=new Label("Courrier");
		TextField textFieldCourrier=new TextField();
		Button buttonAjouter=new Button("Ajouter");
		hBox.getChildren().add(labelCourier);
		hBox.getChildren().add(textFieldCourrier);
		hBox.getChildren().add(buttonAjouter);		
		borderPane.setTop(hBox);
		// Creation d'une liste avec objet VBox et GridPane(division en ligne et colonne)
		VBox vBox=new VBox();
		GridPane gridPane=new GridPane();
		// On cree une liste qui contient des string
		observableList=FXCollections.observableArrayList();
		// Cette liste stocke des données qui sont stoquées dans ObservableListe
		ListView<String> listViewCourrier=new ListView<String>(observableList);
		gridPane.add(listViewCourrier, 0, 0);
		vBox.setPadding(new Insets(10));
		vBox.setSpacing(10);
		// On ajoute gridPane dans VBox
		vBox.getChildren().add(gridPane);
		// Après ce VBox on l'ajoute à Border
		borderPane.setCenter(vBox);
		
		Scene scene=new Scene(borderPane,400,500);
		primaryStage.setScene(scene);
		primaryStage.show();
		// Donnons la possibilité au bouton Ajouter d'ajouter des objets sur la liste
		
		buttonAjouter.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				String courrier=textFieldCourrier.getText();
				// Ajouter et Afficher
				observableList.add(courrier);
				// Création de l'évenement guiEvent, 1 pour un objet on peut mettre un nombre different de 1
				GuiEvent guiEvent=new GuiEvent(this, 1);
				guiEvent.addParameter(courrier);
				// pour l'envoi de message
				
				entrepotAgent.onGuiEvent(guiEvent);
				
			}
		});
		
	}

}
