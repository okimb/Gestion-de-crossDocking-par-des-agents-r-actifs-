package sma.agents;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.gui.GuiAgent;
import jade.gui.GuiEvent;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
// import jade.lang.acl.MessageTemplate;
import jade.wrapper.ControllerException;
import sma.EntrepotContainer;
import sma.WagonContainer;
// Quand un agent utilise une interface, au lieu qu'il soit un heritier de Agent, il doit etre heritier de GuiAgent
public class WagonAgent extends GuiAgent {
	private WagonContainer gui;
	
	//Setup nous permet de gerner le cycle de vie d'un agent
	@Override
	protected void setup() {
		// nous permet de recupperer la refference de l'objet container
		gui=(WagonContainer) getArguments()[0];
		gui.setWagonAgent(this);
		// super.setup();
		System.out.println("Creation et initiatlisation de l'agent: " +this.getAID().getName());
		 /* addBehaviour(new TickerBehaviour(this, 3) {
			
			@Override
			protected void onTick() {
				// TODO Auto-generated method stub
				System.out.println("Charger les marchndises ...");
				
				
			}
		});
		*/
		// Reception de courrier et confirme la reception
		
		addBehaviour(new CyclicBehaviour() {
			
			@Override
			public void action() {
				// On peut aussi filtrer les messages de reception en utilisant MessageTemplate
				MessageTemplate messageTemplate=MessageTemplate.or(MessageTemplate.MatchPerformative(ACLMessage.REQUEST),
						MessageTemplate.MatchPerformative(ACLMessage.REFUSE));
				ACLMessage aclMessage=receive(messageTemplate);
				if(aclMessage!=null) {
					System.out.println(" Reception d'un nouveau message :");
					System.out.println(" Contenu du message: "+aclMessage.getContent());
					// Liste des objects a afficher sous forme de liste les 3 lignes svt
					GuiEvent guiEvent=new GuiEvent(this, 1);
					guiEvent.addParameter(aclMessage.getContent());
					gui.vueMessage(guiEvent);
					System.out.println(" Acte de communication :"
					+aclMessage.getPerformative(aclMessage.getPerformative()));
					System.out.println(" Langage :"+aclMessage.getLanguage());
					System.out.println("Ontologie "+aclMessage.getOntology());
					
					if(aclMessage.getOntology().equals("Marchandises")) {
						System.out.println("Onthologie Marchandise");
						ACLMessage reponse=aclMessage.createReply();
						reponse.setContent("Les marchandises sont arrivées");
						send(reponse);
					}
					else if (aclMessage.getOntology().equals("Courrier")) {
						System.out.println("Onthologie Courrier");
						ACLMessage reponse=aclMessage.createReply();
						reponse.setContent("Les Les courriers sont arrivees");
						send(reponse);						
					}
					}
				else {
					block();
				}
			}
		});
		
		addBehaviour(new Behaviour() {
			// Declaration de compteur pour le controle de comportement
			int compteur=0;
			@Override
			public boolean done() {
				// TODO Auto-generated method stub
				while (compteur<5) {
					return true;
				}
				
				return false;
			}
			
			@Override
			public void action() {
				// TODO Auto-generated method stub
				System.out.println("En route pour entropot...");
				
			}
		});
		
	}
	
	//beforeMove permet Agent de faire le traitement avant migration
	@Override
	protected void beforeMove() {
		// TODO Auto-generated method stub
		// super.beforeMove();		
		try {
			System.out.println(" Avant migration de l'agent: " +this.getAID().getName());
			System.out.println("de "+this.getContainerController().getContainerName());
		} catch (ControllerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	//aferMove permet Agent de faire le traitement après migration
	@Override
	protected void afterMove() {
		// TODO Auto-generated method stub
		try {
			System.out.println("Après migration de l'agent: " +this.getAID().getName());
			System.out.println("vers "+this.getContainerController().getContainerName());
		} catch (ControllerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	//takeDown permet Agent de faire le traitement avant qu'il soit tué
	@Override
	protected void takeDown() {
		// TODO Auto-generated method stub
		// super.takeDown();
		try {
			System.out.println("L'agent "+this.getAID().getName()+ "va mourir");
			System.out.println("au "+this.getContainerController().getContainerName());
		} catch (ControllerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onGuiEvent(GuiEvent guiEvent) {
		// TODO Auto-generated method stub
		// condition pour envoyer un message
		if(guiEvent.getType()==1) {
			// envoie d'un message
			ACLMessage aclMessage=new ACLMessage(ACLMessage.REQUEST);
			String courrier=guiEvent.getParameter(0).toString();
			aclMessage.setContent(courrier);
			aclMessage.addReceiver(new AID("rma", AID.ISLOCALNAME));
			send(aclMessage);
			
			
		}
		
	}

}
