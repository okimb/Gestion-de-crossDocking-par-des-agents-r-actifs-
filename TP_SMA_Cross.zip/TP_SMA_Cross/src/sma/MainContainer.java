package sma;

import jade.core.AgentContainer;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.util.ExtendedProperties;
import jade.util.leap.Properties;
import jade.wrapper.ControllerException;

public class MainContainer {

	public static void main(String[] args) {
		try {
			// Creation d'un objet runtime fornie par jade (c'est une instance jade)
			Runtime runtime=Runtime.instance();
			// Creation d'un objet de type properties
			Properties properties=new ExtendedProperties();
			// Configuration de main container
			properties.setProperty(Profile.GUI, "true");
			// creation d'un objet profile
			Profile profile=new ProfileImpl(properties);
			// Creation de contenaire comme objet de type  Agentcontenaire
			jade.wrapper.AgentContainer mainContainer=runtime.createMainContainer(profile);
			// demare maincontainer;
			mainContainer.start();
		} catch (ControllerException e) {
			e.printStackTrace();
		}
				

	}

}
